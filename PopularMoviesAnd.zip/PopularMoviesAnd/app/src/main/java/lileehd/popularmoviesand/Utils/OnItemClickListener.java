package lileehd.popularmoviesand.Utils;

public interface OnItemClickListener {

    void onVideoClick(int position);
    void onReviewClick(int position);
    void onClickFavBtn();

}
